https://github.com/y988033256/Maze

This file include the maze program and text file that save the record of the maze. 